import json
import boto3
import time

s3 = boto3.client("s3")
ssm = boto3.client("ssm")

def lambda_handler(event, context):
    try:
        data = json.loads(event["body"])
        image_name = data["imageName"]
        user_email = data["userEmail"]

        timestamp = int(time.time())
        file_key = f"{user_email}_{timestamp}_{image_name}"

        bucket_name = ssm.get_parameter(Name="UploadBucketName")["Parameter"]["Value"]

        url = s3.generate_presigned_url(
            ClientMethod="put_object",
            Params={"Bucket": bucket_name, "Key": file_key, "ContentType": "image/png"},
            ExpiresIn=300,
        )

        return {
            "statusCode": 200,
            "headers": {
                "Access-Control-Allow-Origin": "*",
                "Access-Control-Allow-Headers": "Content-Type"
            },
            "body": json.dumps({
                "uploadUrl": url,
                "fileKey": file_key
            })
        }

    except Exception as e:
        return {
            "statusCode": 500,
            "headers": {
                "Access-Control-Allow-Origin": "*",
                "Access-Control-Allow-Headers": "Content-Type"
            },
            "body": json.dumps({"error": str(e)})
        }
