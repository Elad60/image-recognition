import json
import requests
import boto3
from bs4 import BeautifulSoup
from urllib.parse import urljoin

rekognition = boto3.client("rekognition")
DANGEROUS_LABELS = ["Gun", "Knife"]

HEADERS = {
    "User-Agent": "Mozilla/5.0"
}

def lambda_handler(event, context):
    try:
        body = json.loads(event.get("body", "{}"))
        url = body.get("url")

        if not url:
            return {
                "statusCode": 400,
                "headers": {
                    "Access-Control-Allow-Origin": "*",
                    "Access-Control-Allow-Headers": "Content-Type,Authorization"
                },
                "body": json.dumps({"error": "Missing 'url' in request body"})
            }

        response = requests.get(url, headers=HEADERS, timeout=10)
        response.raise_for_status()

        soup = BeautifulSoup(response.text, "html.parser")
        img_tags = soup.find_all("img")

        valid_images = []
        for img in img_tags:
            src = img.get("src")
            if not src:
                continue

            absolute_url = urljoin(url, src)

            try:
                img_resp = requests.get(absolute_url, headers=HEADERS, timeout=5)
                img_resp.raise_for_status()

                # בדיקה שהתמונה מכילה נתונים אמיתיים
                if not img_resp.content or len(img_resp.content) < 1000:
                    continue

                rek_response = rekognition.detect_labels(
                    Image={"Bytes": img_resp.content},
                    MaxLabels=7,
                    MinConfidence=75
                )

                labels = [label["Name"] for label in rek_response["Labels"]]
                is_flagged = any(lbl in DANGEROUS_LABELS for lbl in labels)

                valid_images.append({
                    "image": absolute_url,
                    "labels": labels,
                    "isFlagged": is_flagged
                })

                if len(valid_images) >= 6:
                    break

            except Exception:
                continue

        return {
            "statusCode": 200,
            "headers": {
                "Access-Control-Allow-Origin": "*",
                "Access-Control-Allow-Headers": "Content-Type,Authorization"
            },
            "body": json.dumps({
                "url": url,
                "totalImages": len(valid_images),
                "flaggedCount": sum(img["isFlagged"] for img in valid_images),
                "images": valid_images
            })
        }

    except Exception as e:
        return {
            "statusCode": 500,
            "headers": {
                "Access-Control-Allow-Origin": "*",
                "Access-Control-Allow-Headers": "Content-Type,Authorization"
            },
            "body": json.dumps({"error": str(e)})
        }
