import json
import boto3

dynamodb = boto3.resource("dynamodb")
ssm = boto3.client("ssm")

def lambda_handler(event, context):
    headers = {
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Headers": "Content-Type,Authorization",
    }

    try:
        user_info = event["requestContext"]["authorizer"]["claims"]
        user_email = user_info.get("email")

        table_name = ssm.get_parameter(Name="ImageLabelsTable")["Parameter"]["Value"]
        table = dynamodb.Table(table_name)

        response = table.scan()
        items = response.get("Items", [])

        user_scans = [item for item in items if user_email in item.get("ImageName", "")]

        return {
            "statusCode": 200,
            "headers": headers,
            "body": json.dumps({"scans": user_scans}, default=str),
        }

    except Exception as e:
        return {
            "statusCode": 500,
            "headers": headers,
            "body": json.dumps({"error": str(e)}),
        }
