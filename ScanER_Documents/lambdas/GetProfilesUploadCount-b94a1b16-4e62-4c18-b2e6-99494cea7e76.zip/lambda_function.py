import json
import boto3
from collections import defaultdict

dynamodb = boto3.resource("dynamodb")
ssm = boto3.client("ssm")

def lambda_handler(event, context):
    headers = {
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Headers": "Content-Type,Authorization"
    }

    try:
        table_name = ssm.get_parameter(Name="ImageLabelsTable")["Parameter"]["Value"]
        table = dynamodb.Table(table_name)

        response = table.scan()
        items = response["Items"]

        counts = defaultdict(int)
        for item in items:
            name = item.get("ImageName", "")
            if "_" in name:
                user_prefix = name.split("_")[0]
                counts[user_prefix] += 1

        return {
            "statusCode": 200,
            "headers": headers,
            "body": json.dumps(dict(counts))
        }

    except Exception as e:
        return {
            "statusCode": 500,
            "headers": headers,
            "body": json.dumps({"error": str(e)})
        }
