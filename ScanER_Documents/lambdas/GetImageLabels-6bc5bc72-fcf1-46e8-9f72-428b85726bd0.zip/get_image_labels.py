import json
import boto3
from decimal import Decimal

dynamodb = boto3.resource("dynamodb")
ssm = boto3.client("ssm")

# ✅ מחלקה מותאמת להמרת Decimal ל-float
class DecimalEncoder(json.JSONEncoder):
    def default(self, o):
        if isinstance(o, Decimal):
            return float(o)
        return super(DecimalEncoder, self).default(o)

def handler(event, context):
    table_name = ssm.get_parameter(Name="ImageLabelsTable")["Parameter"]["Value"]
    table = dynamodb.Table(table_name)

    params = event.get("queryStringParameters", {})
    image_name = params.get("imageName")  # תוודא שזה אותו מפתח שאתה שולח מה־Frontend

    if not image_name:
        return {
            "statusCode": 400,
            "body": json.dumps({"error": "Missing image name in query params."})
        }

    response = table.get_item(Key={"ImageName": image_name})
    item = response.get("Item")

    if not item:
        return {"statusCode": 404, "body": json.dumps({"error": "Image not found"})}

    return {
        "statusCode": 200,
        "headers": {
            "Access-Control-Allow-Origin": "*",  # ✅ CORS
        },
        "body": json.dumps({
            "labels": item.get("Labels", []),
            "isDangerous": item.get("IsDangerous", False)
        }, cls=DecimalEncoder)
    }
