import json
import boto3
from decimal import Decimal
from urllib.parse import unquote

rekognition = boto3.client("rekognition")
dynamodb = boto3.resource("dynamodb")
ssm = boto3.client("ssm")
sns = boto3.client("sns")

DANGEROUS_LABELS = ["Gun", "Weapon", "Knife"]

def handler(event, context):
    print("Event:", json.dumps(event))

    bucket = event["Records"][0]["s3"]["bucket"]["name"]
    key_encoded = event["Records"][0]["s3"]["object"]["key"]
    key = unquote(key_encoded)  # חשוב מאוד!

    print(f"Decoded S3 key: {key}")

    # קריאה ל־Rekognition
    rekognition_response = rekognition.detect_labels(
        Image={"S3Object": {"Bucket": bucket, "Name": key}},
        MaxLabels=10,
        MinConfidence=60,
    )

    labels = rekognition_response["Labels"]
    label_data = [
        {"Name": label["Name"], "Confidence": Decimal(str(label["Confidence"]))}
        for label in labels
    ]
    is_dangerous = any(label["Name"] in DANGEROUS_LABELS for label in labels)

    # אחסון ב־DynamoDB
    table_name = ssm.get_parameter(Name="ImageLabelsTable")["Parameter"]["Value"]
    table = dynamodb.Table(table_name)

    table.put_item(Item={
        "ImageName": key,
        "Labels": label_data,
        "IsDangerous": is_dangerous
    })

    # שליחת התראה אם צריך
    if is_dangerous:
        topic_arn = ssm.get_parameter(Name="AlertSNSTopicARN")["Parameter"]["Value"]
        sns.publish(
            TopicArn=topic_arn,
            Subject="⚠️ Dangerous Image Detected",
            Message=f"Image '{key}' contains dangerous content."
        )

    return {
        "statusCode": 200,
        "body": json.dumps("Detection complete.")
    }
