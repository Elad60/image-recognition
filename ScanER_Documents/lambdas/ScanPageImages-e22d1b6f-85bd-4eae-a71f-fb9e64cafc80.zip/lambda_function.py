import json
import boto3
import requests
from bs4 import BeautifulSoup

rekognition = boto3.client("rekognition")

DANGEROUS_LABELS = ["Gun", "Weapon", "Knife"]

def lambda_handler(event, context):
    data = json.loads(event["body"])
    url = data.get("url")

    if not url:
        return {"statusCode": 400, "body": json.dumps({"error": "Missing URL"})}

    response = requests.get(url)
    soup = BeautifulSoup(response.content, "html.parser")
    img_tags = soup.find_all("img")
    img_urls = [img.get("src") for img in img_tags if img.get("src")]

    results = []
    flagged = 0

    for img_url in img_urls[:3]:
        try:
            img_data = requests.get(img_url).content
            labels = rekognition.detect_labels(
                Image={"Bytes": img_data},
                MaxLabels=5,
                MinConfidence=70
            )["Labels"]

            label_names = [label["Name"] for label in labels]
            is_flagged = any(label in DANGEROUS_LABELS for label in label_names)

            if is_flagged:
                flagged += 1

            results.append({
                "image": img_url,
                "labels": label_names,
                "isFlagged": is_flagged
            })
        except Exception as e:
            continue

    return {
        "statusCode": 200,
        "body": json.dumps({
            "url": url,
            "images": results,
            "flaggedCount": flagged,
            "totalImages": len(img_urls)
        })
    }
